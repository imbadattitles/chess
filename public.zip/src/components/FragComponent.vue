<template>
  <slot></slot>
</template>
