<template>
  <div>
    <h3>{{ title }}</h3>
    <div v-for="figure in figures" :key="figure.id">
      {{ figure.name }}
      <img v-if="figure.logo" :src="figure.logo" />
    </div>
  </div>
</template>
<script setup lang="ts">
import type { Figure } from '@/models/figures/figure'

interface Props {
  title: string
  figures: Figure[]
}
const props = defineProps<Props>()
</script>
<style></style>
