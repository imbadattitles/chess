<script setup lang="ts">
import BoardComponent from './components/BoardComponent.vue'
import { ref, onMounted, type Ref } from 'vue'
import { Board } from './models/Board'
import { Player } from './models/Player'
import { Colors } from './models/Colors'
import LostFigures from './components/LostFigures.vue'
const board = ref(new Board()) as Ref<Board>

const restart = () => {
  const newBoard = new Board()
  newBoard.initCells()
  newBoard.AddFigures()
  board.value = newBoard
}

onMounted(() => {
  restart()
  currentPlayer.value = whitePlayer.value
})
const updateBoard = (value: Board) => {
  board.value = value
}
const whitePlayer = ref(new Player(Colors.WHITE))
const blackPlayer = ref(new Player(Colors.BLACK))
const currentPlayer = ref<Player | null>(null)

const swapPlayer = () => {
  currentPlayer.value?.color === Colors.WHITE
    ? (currentPlayer.value = blackPlayer.value)
    : (currentPlayer.value = whitePlayer.value)
}
</script>

<template>
  <main class="app">
    <BoardComponent
      @swap-player="swapPlayer"
      :board="board"
      :current-player="currentPlayer"
      @update-board="updateBoard"
    />
    <div>
      <LostFigures
        :title="`Потеряно черных фигур ${board.lostBlackFigures.length}`"
        :figures="board.lostBlackFigures"
      />
      <LostFigures
        :title="`Потеряно белых фигур ${board.lostWhiteFigures.length}`"
        :figures="board.lostWhiteFigures"
      />
    </div>
  </main>
</template>

<style>
* {
  margin: 0;
  padding: 0;
}

.app {
  width: 100vw;
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.board {
  width: calc(64px * 8);
  height: calc(64px * 8);
  display: flex;
  flex-wrap: wrap;
}

.cell {
  width: 64px;
  height: 64px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.black {
  background-color: deepskyblue;
}

.white {
  background: rgb(255, 228, 177);
}
</style>
